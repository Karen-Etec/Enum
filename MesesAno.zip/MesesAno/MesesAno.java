/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package br.edu.etec.MesesAno.model;

/**
 *
 * @author musas
 */
public enum MesesAno {
    JANEIRO(1),
    FEVEREIRO(2),
    MARCO(3),
    ABRIL(4),
    MAIO(5),
    JUNHO(6),
    JULHO(7),
    AGOSTO(8),
    SETEMBRO(9),
    OUTUBRO(10),
    NOVEMBRO(11),
    DEZEMBRO(12);

    private final int descricao;

    MesesAno(int descricao) {
        this.descricao = descricao;
    }

    public int getDescricao() {
        return descricao;
    }

    public static MesesAno numeroMes(int descricao) {
        for (MesesAno mes : MesesAno.values()) {
            if (mes.getDescricao() == descricao) {
                return mes;
            }
        }
        return null;
    }
}

